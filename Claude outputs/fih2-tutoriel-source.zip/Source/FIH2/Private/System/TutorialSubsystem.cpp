#include "System/TutorialSubsystem.h"

#include "Blueprint/UserWidget.h"
#include "Camera/PlayerCameraManager.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Fish/Fish.h"
#include "Fish/PredatorFish.h"
#include "Inanimate/Kelp.h"
#include "System/MouseController.h"
#include "System/TutorialWidget.h"

DEFINE_LOG_CATEGORY_STATIC(LogTutorial, Log, All);

#define LOCTEXT_NAMESPACE "FIH2Tutorial"

namespace TutorialRules
{
	/** TUTO_ANGLE_CAMERA [°] : une rotation de caméra de cet angle valide aussi l'étape MoveCamera. */
	constexpr float CameraTurnDegrees = 20.f;
	/** Kelps « éloignés » choisis automatiquement quand aucun n'est tagué (niveau 1 : 2 kelps à déplacer). */
	constexpr int32 FallbackFarKelpCount = 2;
	/** TUTO_DUREE_ALERTE [s] : durée d'affichage de l'alerte « le compte à rebours repart de zéro ». */
	constexpr float ResetWarningDuration = 4.f;
	/** Ordre d'affichage du panneau au-dessus du HUD. */
	constexpr int32 PanelZOrder = 20;
}

UTutorialSubsystem* UTutorialSubsystem::Get(const UObject* WorldContext)
{
	const UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContext, EGetWorldErrorMode::ReturnNull) : nullptr;
	return World ? World->GetSubsystem<UTutorialSubsystem>() : nullptr;
}

bool UTutorialSubsystem::DoesSupportWorldType(const EWorldType::Type WorldType) const
{
	return WorldType == EWorldType::Game || WorldType == EWorldType::PIE;
}

void UTutorialSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Collection.InitializeDependency<UEcosystemSubsystem>();
	Super::Initialize(Collection);
}

void UTutorialSubsystem::Deinitialize()
{
	Stop();
	Super::Deinitialize();
}

void UTutorialSubsystem::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);

	Ecosystem = UEcosystemSubsystem::Get(&InWorld);
	Config = Ecosystem ? Ecosystem->EnsureLevelConfig() : nullptr;
	if (!Config || !Config->bIsTutorial || Config->TutorialSteps.Num() == 0)
	{
		return;
	}

	// Phase guidée : rien ne peut être perdu avant l'étape finale.
	Ecosystem->SetDefeatEnabled(false);
	Ecosystem->SetTimedObjectiveEnabled(false);
	Ecosystem->SetStarvationDeathAllowed(false);

	Ecosystem->OnUpdated.AddUniqueDynamic(this, &UTutorialSubsystem::HandleEcosystemUpdated);
	Ecosystem->OnStateChanged.AddUniqueDynamic(this, &UTutorialSubsystem::HandleEcosystemStateChanged);
	bActive = true;
	bStarted = false;
	StepIndex = -1;
}

// ------------------------------------------------------------------ Démarrage / arrêt

void UTutorialSubsystem::Start()
{
	bStarted = true;
	UWorld* World = GetWorld();
	APlayerController* PC = World ? World->GetFirstPlayerController() : nullptr;

	Controller = Cast<AMouseController>(PC);
	if (Controller.IsValid())
	{
		Controller->OnSelectionChanged.AddUniqueDynamic(this, &UTutorialSubsystem::HandleSelectionChanged);
	}
	else
	{
		UE_LOG(LogTutorial, Warning, TEXT("Pas d'AMouseController : les étapes de sélection et de saisie ne pourront pas être validées."));
	}

	if (PC)
	{
		const TSubclassOf<UTutorialWidget> WidgetClass = Config->TutorialWidgetClass
			? Config->TutorialWidgetClass : TSubclassOf<UTutorialWidget>(UTutorialWidget::StaticClass());
		Widget = CreateWidget<UTutorialWidget>(PC, WidgetClass);
		if (Widget)
		{
			Widget->AddToViewport(TutorialRules::PanelZOrder);
			Widget->SetAnchorsInViewport(FAnchors(0.5f, 0.f));
			Widget->SetAlignmentInViewport(FVector2D(0.5f, 0.f));
			Widget->SetPositionInViewport(FVector2D(0.f, Config->TutorialPanelTopOffset), false);
		}
	}

	ResolveFarKelps();
	EnterStep(0);
}

void UTutorialSubsystem::Stop()
{
	bActive = false;
	if (Widget)
	{
		Widget->RemoveFromParent();
		Widget = nullptr;
	}
	if (Ecosystem)
	{
		Ecosystem->OnUpdated.RemoveDynamic(this, &UTutorialSubsystem::HandleEcosystemUpdated);
		Ecosystem->OnStateChanged.RemoveDynamic(this, &UTutorialSubsystem::HandleEcosystemStateChanged);
	}
	if (Controller.IsValid())
	{
		Controller->OnSelectionChanged.RemoveDynamic(this, &UTutorialSubsystem::HandleSelectionChanged);
	}
}

// ------------------------------------------------------------------ Étapes

void UTutorialSubsystem::EnterStep(int32 NewIndex)
{
	const TArray<FTutorialStep>& Steps = Config->TutorialSteps;
	if (!Steps.IsValidIndex(NewIndex))
	{
		// Liste sans étape FinalHold : le tutoriel se termine sur une victoire à la fin des étapes.
		UE_LOG(LogTutorial, Log, TEXT("Tutoriel terminé (fin des étapes)."));
		OnCompleted.Broadcast();
		if (Ecosystem)
		{
			Ecosystem->FinishLevel(true);
		}
		Stop();
		return;
	}

	StepIndex = NewIndex;
	StepTime = 0.f;
	StepCounter = 0.f;
	WarningTimeLeft = 0.f;
	bFishSelected = false;

	if (const APlayerController* PC = GetWorld() ? GetWorld()->GetFirstPlayerController() : nullptr)
	{
		if (PC->PlayerCameraManager)
		{
			CameraStartLocation = PC->PlayerCameraManager->GetCameraLocation();
			CameraStartRotation = PC->PlayerCameraManager->GetCameraRotation();
		}
	}

	const FTutorialStep& Step = Steps[StepIndex];
	if (Step.Type == ETutorialStepType::FinalHold && Ecosystem)
	{
		// Étape finale : la partie redevient « réelle ».
		Ecosystem->SetDefeatEnabled(true);
		Ecosystem->SetStarvationDeathAllowed(true);
	}

	if (Widget)
	{
		Widget->ShowStep(StepIndex + 1, Steps.Num(), Step.Title, Step.Message);
	}

	UE_LOG(LogTutorial, Log, TEXT("Tutoriel : étape %d / %d (%s)"), StepIndex + 1, Steps.Num(), *UEnum::GetValueAsString(Step.Type));
	OnStepChanged.Broadcast(StepIndex, Step.Type);
}

void UTutorialSubsystem::SkipStep()
{
	if (bActive && bStarted)
	{
		EnterStep(StepIndex + 1);
	}
}

void UTutorialSubsystem::HandleEcosystemUpdated(const FEcosystemSnapshot& Snapshot)
{
	if (!bActive || !Config)
	{
		return;
	}
	if (!bStarted)
	{
		LastElapsed = Snapshot.ElapsedTime;
		Start();
		return;
	}

	const float Dt = FMath::Max(0.f, Snapshot.ElapsedTime - LastElapsed);
	LastElapsed = Snapshot.ElapsedTime;

	if (!Config->TutorialSteps.IsValidIndex(StepIndex))
	{
		return;
	}
	const FTutorialStep& Step = Config->TutorialSteps[StepIndex];
	StepTime += Dt;

	if (Step.Type == ETutorialStepType::FinalHold)
	{
		UpdateFinalHold(Step, Snapshot, Dt);
		return;
	}

	const bool bTimedOut = Step.MaxDuration > 0.f && StepTime >= Step.MaxDuration;
	if (bTimedOut || (IsStepDone(Step, Snapshot, Dt) && StepTime >= Step.MinDuration))
	{
		EnterStep(StepIndex + 1);
	}
}

bool UTutorialSubsystem::IsStepDone(const FTutorialStep& Step, const FEcosystemSnapshot& Snapshot, float Dt)
{
	switch (Step.Type)
	{
	case ETutorialStepType::MoveCamera:
	{
		const APlayerController* PC = GetWorld() ? GetWorld()->GetFirstPlayerController() : nullptr;
		if (!PC || !PC->PlayerCameraManager)
		{
			return true; // pas de caméra à tester : on ne bloque pas le joueur
		}
		const float Moved = FVector::Dist(PC->PlayerCameraManager->GetCameraLocation(), CameraStartLocation);
		const float TurnedDeg = FMath::RadiansToDegrees(
			PC->PlayerCameraManager->GetCameraRotation().Quaternion().AngularDistance(CameraStartRotation.Quaternion()));
		return Moved >= Step.Value || TurnedDeg >= TutorialRules::CameraTurnDegrees;
	}

	case ETutorialStepType::SelectFish:
		return bFishSelected;

	case ETutorialStepType::DragObject:
		if (Controller.IsValid() && Controller->GetIsDragging())
		{
			StepCounter += Dt;
		}
		return StepCounter >= Step.Value;

	case ETutorialStepType::Observe:
		return StepTime >= Step.Value;

	case ETutorialStepType::WaitHungerRising:
		return Snapshot.StressHunger >= Step.Value;

	case ETutorialStepType::FeedFish:
		if (Widget)
		{
			Widget->SetProgress(FText::Format(LOCTEXT("FeedProgress", "Poissons affamés : {0} %"),
				FText::AsNumber(FMath::RoundToInt(Snapshot.StarvingPercent))));
		}
		return Snapshot.StarvingPercent <= 0.f;

	case ETutorialStepType::GatherKelps:
	{
		FarKelps.RemoveAll([](const TWeakObjectPtr<AKelp>& K) { return !K.IsValid(); });
		const FVector Center = GetNearKelpsCenter();
		int32 Gathered = 0;
		for (const TWeakObjectPtr<AKelp>& K : FarKelps)
		{
			// Distance horizontale : le relief du fond ne doit pas compter.
			if (FVector::Dist2D(K->GetActorLocation(), Center) <= Step.Value)
			{
				++Gathered;
			}
		}
		if (Widget && FarKelps.Num() > 0)
		{
			Widget->SetProgress(FText::Format(LOCTEXT("KelpProgress", "Kelps rapprochés : {0} / {1}"),
				FText::AsNumber(Gathered), FText::AsNumber(FarKelps.Num())));
		}
		return Gathered >= FarKelps.Num();
	}

	default:
		return true;
	}
}

void UTutorialSubsystem::UpdateFinalHold(const FTutorialStep& Step, const FEcosystemSnapshot& Snapshot, float Dt)
{
	const bool bRed = Snapshot.Gauge >= Config->TutorialRedGauge;
	if (bRed)
	{
		// Décision du 13/11 : un passage au rouge remet le compte à rebours à zéro, avec une indication.
		WarningTimeLeft = TutorialRules::ResetWarningDuration;
		StepCounter = 0.f;
	}
	else
	{
		StepCounter += Dt;
		WarningTimeLeft = FMath::Max(0.f, WarningTimeLeft - Dt);
	}

	if (Widget)
	{
		Widget->SetProgress(FText::Format(LOCTEXT("HoldProgress", "Jauge hors du rouge : {0} / {1} s"),
			FText::AsNumber(FMath::FloorToInt(StepCounter)), FText::AsNumber(FMath::RoundToInt(Step.Value))));
		Widget->SetWarning(WarningTimeLeft > 0.f
			? (bRed ? LOCTEXT("HoldRed", "La jauge est au rouge : le compte à rebours repart de zéro.")
			        : LOCTEXT("HoldRestarted", "Le compte à rebours a redémarré."))
			: FText::GetEmpty());
	}

	if (StepCounter >= Step.Value)
	{
		UE_LOG(LogTutorial, Log, TEXT("Tutoriel réussi : maintien de %.0f s atteint."), Step.Value);
		OnCompleted.Broadcast();
		if (Ecosystem)
		{
			Ecosystem->FinishLevel(true); // l'écran de fin du HUD se déclenche via OnStateChanged
		}
		Stop();
	}
}

// ------------------------------------------------------------------ Événements

void UTutorialSubsystem::HandleEcosystemStateChanged(EEcosystemState NewState)
{
	if (NewState != EEcosystemState::Playing)
	{
		Stop(); // victoire ou défaite : l'écran de fin du HUD prend le relais
	}
}

void UTutorialSubsystem::HandleSelectionChanged(AActor* NewSelection)
{
	if (Cast<AFish>(NewSelection))
	{
		bFishSelected = true;
	}
}

// ------------------------------------------------------------------ Kelps

void UTutorialSubsystem::ResolveFarKelps()
{
	FarKelps.Reset();
	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	TArray<AKelp*> AllKelps;
	for (TActorIterator<AKelp> It(World); It; ++It)
	{
		AllKelps.Add(*It);
		if (!Config->TutorialFarKelpTag.IsNone() && It->ActorHasTag(Config->TutorialFarKelpTag))
		{
			FarKelps.Add(*It);
		}
	}
	if (FarKelps.Num() > 0 || AllKelps.Num() <= TutorialRules::FallbackFarKelpCount)
	{
		UE_LOG(LogTutorial, Log, TEXT("Tutoriel : %d kelp(s) éloigné(s) tagué(s) « %s »."), FarKelps.Num(), *Config->TutorialFarKelpTag.ToString());
		return;
	}

	// Pas de tag : les kelps les plus loin des poissons au démarrage.
	FVector FishCenter = FVector::ZeroVector;
	int32 FishCount = 0;
	for (TActorIterator<AFish> It(World); It; ++It)
	{
		if (!It->IsA<APredatorFish>())
		{
			FishCenter += It->GetActorLocation();
			++FishCount;
		}
	}
	if (FishCount == 0)
	{
		return;
	}
	FishCenter /= FishCount;

	AllKelps.Sort([&FishCenter](const AKelp& A, const AKelp& B)
	{
		return FVector::DistSquared2D(A.GetActorLocation(), FishCenter) > FVector::DistSquared2D(B.GetActorLocation(), FishCenter);
	});
	for (int32 i = 0; i < TutorialRules::FallbackFarKelpCount; ++i)
	{
		FarKelps.Add(AllKelps[i]);
		UE_LOG(LogTutorial, Log, TEXT("Tutoriel : kelp éloigné détecté automatiquement : %s"), *AllKelps[i]->GetName());
	}
}

FVector UTutorialSubsystem::GetNearKelpsCenter() const
{
	FVector Sum = FVector::ZeroVector;
	int32 Count = 0;
	if (UWorld* World = GetWorld())
	{
		for (TActorIterator<AKelp> It(World); It; ++It)
		{
			if (!FarKelps.Contains(TWeakObjectPtr<AKelp>(*It)))
			{
				Sum += It->GetActorLocation();
				++Count;
			}
		}
		if (Count == 0)
		{
			// Aucun kelp « proche » : on vise les poissons.
			for (TActorIterator<AFish> It(World); It; ++It)
			{
				Sum += It->GetActorLocation();
				++Count;
			}
		}
	}
	return Count > 0 ? Sum / Count : FVector::ZeroVector;
}

#undef LOCTEXT_NAMESPACE

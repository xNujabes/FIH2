#include "System/LevelConfig.h"

#define LOCTEXT_NAMESPACE "FIH2Tutorial"

namespace
{
	FTutorialStep MakeStep(ETutorialStepType Type, const FText& Title, const FText& Message, float Value,
		float MinDuration = 3.f, float MaxDuration = 0.f)
	{
		FTutorialStep Step;
		Step.Type = Type;
		Step.Title = Title;
		Step.Message = Message;
		Step.Value = Value;
		Step.MinDuration = MinDuration;
		Step.MaxDuration = MaxDuration;
		return Step;
	}
}

ULevelConfig::ULevelConfig()
{
	// Tutoriel du niveau 1 (8 étapes). Textes et valeurs modifiables dans le Data Asset ; les touches exactes
	// dépendent de IMC_Sandbox, à préciser dans les messages si besoin.
	TutorialSteps = {
		// 1-3 : prise en main des contrôles
		MakeStep(ETutorialStepType::MoveCamera,
			LOCTEXT("S1Title", "Bienvenue dans ta cuve"),
			LOCTEXT("S1Msg", "Déplace, tourne ou zoome la caméra pour faire le tour de la cuve."),
			/* TUTO_DISTANCE_CAMERA [cm] */ 600.f),
		MakeStep(ETutorialStepType::SelectFish,
			LOCTEXT("S2Title", "Inspecter"),
			LOCTEXT("S2Msg", "Clique sur un poisson : son panneau d'infos s'ouvre en bas à droite.\nLa loupe y place la caméra devant lui."),
			0.f),
		MakeStep(ETutorialStepType::DragObject,
			LOCTEXT("S3Title", "Attraper et déplacer"),
			LOCTEXT("S3Msg", "Maintiens le clic sur un poisson, une pierre ou un kelp pour l'attraper, déplace-le, puis relâche (ou lance-le)."),
			/* TUTO_DUREE_SAISIE [s] */ 1.f),
		// 4 : observation des poissons
		MakeStep(ETutorialStepType::Observe,
			LOCTEXT("S4Title", "Observer"),
			LOCTEXT("S4Msg", "Tes poissons nagent et cherchent les fruits mûrs des kelps.\nBien nourris, ils pondent des œufs qui deviennent des alevins."),
			/* TUTO_DUREE_OBSERVATION [s] */ 15.f),
		// 5-7 : les jauges
		MakeStep(ETutorialStepType::WaitHungerRising,
			LOCTEXT("S5Title", "Les jauges"),
			LOCTEXT("S5Msg", "En bas à gauche : pollution, oxygène et faim. Ensemble, elles forment la jauge de dérèglement.\nRegarde la faim : elle monte."),
			/* TUTO_STRESS_FAIM [0-100] */ 40.f, 5.f, /* si les poissons se nourrissent seuls */ 60.f),
		MakeStep(ETutorialStepType::FeedFish,
			LOCTEXT("S6Title", "Nourrir"),
			LOCTEXT("S6Msg", "Un poisson a faim ! Attrape un fruit de kelp mûr et lâche-le près de lui.\nUn poisson rassasié ne mange pas : la nourriture en trop pourrit et pollue."),
			0.f, 3.f, /* pas de fruit mûr disponible */ 90.f),
		MakeStep(ETutorialStepType::GatherKelps,
			LOCTEXT("S7Title", "Rapprocher les kelps"),
			LOCTEXT("S7Msg", "Deux kelps sont trop loin : leurs fruits pourrissent sans être mangés.\nAttrape-les et rapproche-les des autres pour que les poissons se nourrissent seuls et que la pollution baisse."),
			/* TUTO_RAYON_KELPS [cm] */ 3000.f),
		// 8 : maintien final (défaite réactivée)
		MakeStep(ETutorialStepType::FinalHold,
			LOCTEXT("S8Title", "Dernière épreuve"),
			LOCTEXT("S8Msg", "Garde la jauge de dérèglement hors du rouge pendant 1 minute.\nAttention : à partir de maintenant, la partie peut être perdue."),
			/* TUTO_DUREE_MAINTIEN [s] */ 60.f, 0.f),
	};
}

#undef LOCTEXT_NAMESPACE

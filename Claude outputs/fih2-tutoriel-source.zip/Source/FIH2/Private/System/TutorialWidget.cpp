#include "System/TutorialWidget.h"

#include "Blueprint/WidgetTree.h"
#include "Components/Border.h"
#include "Components/SizeBox.h"
#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"
#include "Components/VerticalBoxSlot.h"
#include "Styling/CoreStyle.h"

#define LOCTEXT_NAMESPACE "FIH2Tutorial"

namespace TutorialWidgetLayout
{
	// Tailles de police [pt] et espacements [px] du panneau par défaut.
	constexpr int32 StepFontSize = 11;
	constexpr int32 TitleFontSize = 18;
	constexpr int32 BodyFontSize = 13;
	constexpr float PaddingX = 22.f;
	constexpr float PaddingY = 14.f;
	constexpr float LineGap = 6.f;
}

TSharedRef<SWidget> UTutorialWidget::RebuildWidget()
{
	// Classe C++ utilisée directement : pas d'arbre issu d'un designer, on construit le panneau par défaut.
	if (!WidgetTree || !WidgetTree->RootWidget)
	{
		BuildDefaultTree();
	}
	return Super::RebuildWidget();
}

void UTutorialWidget::NativeOnInitialized()
{
	Super::NativeOnInitialized();
	// Le panneau ne doit jamais bloquer le clic, la sélection ni le drag & throw.
	SetVisibility(ESlateVisibility::HitTestInvisible);
}

void UTutorialWidget::BuildDefaultTree()
{
	using namespace TutorialWidgetLayout;

	if (!WidgetTree)
	{
		WidgetTree = NewObject<UWidgetTree>(this, TEXT("WidgetTree"), RF_Transient);
	}

	USizeBox* Root = WidgetTree->ConstructWidget<USizeBox>(USizeBox::StaticClass(), TEXT("Root"));
	Root->SetMaxDesiredWidth(PanelMaxWidth);
	WidgetTree->RootWidget = Root;

	UBorder* Background = WidgetTree->ConstructWidget<UBorder>(UBorder::StaticClass(), TEXT("Background"));
	Background->SetBrushColor(BackgroundColor);
	Background->SetPadding(FMargin(PaddingX, PaddingY));
	Root->AddChild(Background);

	UVerticalBox* Lines = WidgetTree->ConstructWidget<UVerticalBox>(UVerticalBox::StaticClass(), TEXT("Lines"));
	Background->AddChild(Lines);

	auto AddLine = [&](FName Name, const TCHAR* Typeface, int32 Size, const FLinearColor& Color) -> UTextBlock*
	{
		UTextBlock* Block = WidgetTree->ConstructWidget<UTextBlock>(UTextBlock::StaticClass(), Name);
		Block->SetFont(FCoreStyle::GetDefaultFontStyle(Typeface, Size));
		Block->SetColorAndOpacity(FSlateColor(Color));
		Block->SetAutoWrapText(true);
		if (UVerticalBoxSlot* LineSlot = Lines->AddChildToVerticalBox(Block))
		{
			LineSlot->SetPadding(FMargin(0.f, 0.f, 0.f, LineGap));
		}
		return Block;
	};

	StepText = AddLine(TEXT("StepText"), TEXT("Regular"), StepFontSize, AccentColor);
	TitleText = AddLine(TEXT("TitleText"), TEXT("Bold"), TitleFontSize, FLinearColor::White);
	MessageText = AddLine(TEXT("MessageText"), TEXT("Regular"), BodyFontSize, FLinearColor(0.9f, 0.93f, 0.95f, 1.f));
	ProgressText = AddLine(TEXT("ProgressText"), TEXT("Bold"), BodyFontSize, AccentColor);
	WarningText = AddLine(TEXT("WarningText"), TEXT("Bold"), BodyFontSize, WarningColor);

	ProgressText->SetVisibility(ESlateVisibility::Collapsed);
	WarningText->SetVisibility(ESlateVisibility::Collapsed);
}

void UTutorialWidget::SetLine(UTextBlock* Block, const FText& Text)
{
	if (!Block)
	{
		return;
	}
	Block->SetText(Text);
	Block->SetVisibility(Text.IsEmpty() ? ESlateVisibility::Collapsed : ESlateVisibility::HitTestInvisible);
}

void UTutorialWidget::ShowStep(int32 StepNumber, int32 StepCount, const FText& Title, const FText& Message)
{
	SetLine(StepText, FText::Format(LOCTEXT("StepCounter", "TUTORIEL  {0} / {1}"), StepNumber, StepCount));
	SetLine(TitleText, Title);
	SetLine(MessageText, Message);
	SetLine(ProgressText, FText::GetEmpty());
	SetLine(WarningText, FText::GetEmpty());
	OnStepShown(StepNumber, StepCount);
}

void UTutorialWidget::SetProgress(const FText& Progress)
{
	if (ProgressText && !ProgressText->GetText().EqualTo(Progress))
	{
		SetLine(ProgressText, Progress);
	}
}

void UTutorialWidget::SetWarning(const FText& Warning)
{
	if (WarningText && !WarningText->GetText().EqualTo(Warning))
	{
		SetLine(WarningText, Warning);
	}
}

#undef LOCTEXT_NAMESPACE

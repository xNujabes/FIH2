// Configuration data-driven d'un niveau : mission, jauge de dérèglement et paramètres écologiques.
// Toutes les valeurs sont éditables sans recompiler (créer un Data Asset de cette classe).
// Les noms de paramètres de conception (MAJUSCULES_SNAKE_CASE) sont rappelés en commentaire.
// Unités : secondes réelles (1 s réelle = 1 s de simulation) ; stress, pollution et oxygène sur 0–100.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "LevelConfig.generated.h"

class UTutorialWidget;

/** Type d'une étape du tutoriel : définit la condition qui la valide (voir UTutorialSubsystem). */
UENUM(BlueprintType)
enum class ETutorialStepType : uint8
{
	/** Le joueur déplace, tourne ou zoome la caméra. Value = distance [cm] à parcourir (la rotation compte aussi). */
	MoveCamera UMETA(DisplayName = "Bouger la caméra"),
	/** Le joueur clique sur un poisson (le panneau d'infos s'ouvre). */
	SelectFish UMETA(DisplayName = "Sélectionner un poisson"),
	/** Le joueur attrape un objet et le déplace. Value = durée de saisie cumulée [s]. */
	DragObject UMETA(DisplayName = "Attraper un objet"),
	/** Simple observation. Value = durée [s]. */
	Observe UMETA(DisplayName = "Observer"),
	/** Attend que la faim monte. Value = stress de faim (0–100) à atteindre. */
	WaitHungerRising UMETA(DisplayName = "Attendre la faim"),
	/** Le joueur nourrit les poissons : plus aucun poisson affamé. */
	FeedFish UMETA(DisplayName = "Nourrir un poisson"),
	/** Les kelps éloignés sont rapprochés des autres. Value = rayon [cm] autour du groupe de kelps proches. */
	GatherKelps UMETA(DisplayName = "Rapprocher les kelps"),
	/** Étape finale : défaite réactivée, maintenir la jauge hors du rouge. Value = durée [s]. */
	FinalHold UMETA(DisplayName = "Maintien final")
};

/** Une étape du tutoriel : texte affiché + condition de validation. */
USTRUCT(BlueprintType)
struct FTutorialStep
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial")
	ETutorialStepType Type = ETutorialStepType::Observe;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial")
	FText Title;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (MultiLine = true))
	FText Message;

	/** Paramètre de la condition (sens selon Type, voir ETutorialStepType). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (ClampMin = "0"))
	float Value = 0.f;

	/** TUTO_DUREE_MIN_ETAPE [s] : temps minimal d'affichage avant de passer à la suite (évite les messages qui clignotent). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (ClampMin = "0"))
	float MinDuration = 3.f;

	/** TUTO_DUREE_MAX_ETAPE [s] : au-delà, l'étape est validée d'office (anti-blocage). 0 = pas de limite. Ignoré par FinalHold. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (ClampMin = "0"))
	float MaxDuration = 0.f;
};


UCLASS(BlueprintType)
class FIH2_API ULevelConfig : public UDataAsset
{
	GENERATED_BODY()

public:
	ULevelConfig();

	// ---------------------------------------------------------------- Mission (D-01)
	/** OBJECTIF_POISSONS_BASE : adultes de base vivants requis à la fin du niveau (D-01 : 5). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission", meta = (ClampMin = "1"))
	int32 ObjectiveAdultFish = 5;

	/** DUREE_NIVEAU [s] : la victoire est évaluée à cet instant (option B). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission", meta = (ClampMin = "10"))
	float LevelDuration = 300.f;

	/** DELAI_EXTINCTION [s] : durée pendant laquelle il peut manquer des adultes (< 2, sans alevin ni œuf) avant la défaite. Laisse le temps de reposer un poisson. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mission", meta = (ClampMin = "0"))
	float ExtinctionGraceTime = 15.f;

	// ---------------------------------------------------------------- Jauge de dérèglement (D-02, D-03)
	/** SEUIL_JAUNE : un stress à partir de cette valeur passe en zone jaune. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0", ClampMax = "100"))
	float YellowThreshold = 40.f;

	/** SEUIL_ROUGE_VARIABLE : un stress à partir de cette valeur passe en zone rouge. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0", ClampMax = "100"))
	float RedThreshold = 70.f;

	/** COEF_ZONE_VERT : poids d'un stress en zone verte dans la moyenne pondérée. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0.01"))
	float CoefGreen = 0.5f;

	/** COEF_ZONE_JAUNE */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0.01"))
	float CoefYellow = 1.f;

	/** COEF_ZONE_ROUGE */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0.01"))
	float CoefRed = 2.f;

	/** SEUIL_DEFAITE_JAUGE : la jauge globale D à partir de laquelle le timer de défaite monte. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "1", ClampMax = "100"))
	float DefeatGaugeThreshold = 50.f;

	/** DUREE_DEFAITE [s] : le timer de défaite doit atteindre cette valeur. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "1"))
	float DefeatDuration = 30.f;

	/** DECROISSANCE_TIMER_DEFAITE : vitesse de descente du timer (× temps réel) quand D repasse sous le seuil. Évite le reset par oscillation. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gauge", meta = (ClampMin = "0", ClampMax = "1"))
	float DefeatTimerDecay = 0.5f;

	// ---------------------------------------------------------------- Simulation (D-07)
	/** SIM_TICK [s] : pas fixe de la simulation, découplé du framerate. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Simulation", meta = (ClampMin = "0.1", ClampMax = "2"))
	float SimTick = 0.5f;

	// ---------------------------------------------------------------- Pollution (D-04)
	/** POLLUTION_NOURRITURE_POURRIE [/s/unité] : pollution émise par un fruit à l'état Decaying. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pollution", meta = (ClampMin = "0"))
	float PollutionPerDecayingFood = 0.05f;

	/** POLLUTION_CADAVRE [/s/cadavre] : pollution émise par un poisson mort (faim ou asphyxie). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pollution", meta = (ClampMin = "0"))
	float PollutionPerCorpse = 0.15f;

	/** DUREE_CADAVRE [s] : durée pendant laquelle un cadavre pollue (le poisson mort est déjà détruit, c'est un compteur virtuel). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pollution", meta = (ClampMin = "1"))
	float CorpsePollutionDuration = 60.f;

	/** EPURATION_BASE [/s] : auto-épuration naturelle. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pollution", meta = (ClampMin = "0"))
	float BasePurification = 0.03f;

	/** EPURATION_KELP [/s/kelp mûr] */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pollution", meta = (ClampMin = "0"))
	float PurificationPerKelp = 0.02f;

	// ---------------------------------------------------------------- Oxygène (D-04)
	/** O2_DEPART [0–100] */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0", ClampMax = "100"))
	float StartOxygen = 90.f;

	/** O2_PROD_BASE [/s] : échange avec la surface. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float BaseOxygenProduction = 0.3f;

	/** O2_PROD_KELP [/s/kelp mûr] */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float OxygenPerMatureKelp = 0.12f;

	/** O2_CONSO_ADULTE [/s/poisson] */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float AdultOxygenConsumption = 0.10f;

	/** Facteur appliqué à la consommation d'un alevin (0,5 = moitié d'un adulte). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float FryOxygenFactor = 0.5f;

	/** O2_CONSO_POLLUTION [/s par point de pollution] : la décomposition consomme de l'oxygène. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float OxygenConsumptionPerPollution = 0.004f;

	/** O2_SEUIL_ASPHYXIE : sous cette valeur d'oxygène, les poissons meurent. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0", ClampMax = "100"))
	float AsphyxiaThreshold = 15.f;

	/** MORT_ASPHYXIE [/s/poisson] : probabilité de mort par seconde sous le seuil. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Oxygen", meta = (ClampMin = "0"))
	float AsphyxiaDeathRate = 0.02f;

	// ---------------------------------------------------------------- Faim
	/** Un poisson dont Hunger <= cette valeur est « affamé » (BP_Fish : Hunger -1 toutes les 20 s, détruit à 0 au tick suivant). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Hunger", meta = (ClampMin = "0", ClampMax = "3"))
	int32 StarvingHungerMax = 0;

	// ---------------------------------------------------------------- Reproduction (D-06)
	/** Désactive la reproduction dans ce niveau. Les réglages de ponte, d'œuf et d'alevin sont propres à chaque
	 *  espèce : voir AFish::Reproduction dans le Blueprint du poisson. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Reproduction")
	bool bReproductionEnabled = true;

	/** MAX_POISSONS_TOTAL : garde-fou de performance (adultes + alevins + œufs). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Reproduction", meta = (ClampMin = "2"))
	int32 MaxFishTotal = 40;

	// ---------------------------------------------------------------- Tutoriel
	/** Ce niveau est un tutoriel : étapes guidées ; défaite et mort de faim désactivées jusqu'à l'étape FinalHold ;
	 *  la victoire est donnée par le maintien final (l'objectif chronométré DUREE_NIVEAU est ignoré, le chrono tourne quand même). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial")
	bool bIsTutorial = true;

	/** Étapes, dans l'ordre. Valeurs par défaut remplies par le constructeur (niveau 1). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (EditCondition = "bIsTutorial", TitleProperty = "Title"))
	TArray<FTutorialStep> TutorialSteps;

	/** TUTO_SEUIL_ROUGE_JAUGE : pendant le maintien final, la jauge D est « au rouge » à partir de cette valeur
	 *  (le compte à rebours repart alors de zéro). Par défaut = SEUIL_DEFAITE_JAUGE (50), seuil où le timer de défaite
	 *  commence à monter. À aligner sur la couleur rouge de la jauge du HUD. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (EditCondition = "bIsTutorial", ClampMin = "1", ClampMax = "100"))
	float TutorialRedGauge = 50.f;

	/** Tag d'acteur des kelps « éloignés » à rapprocher. Sans kelp tagué : les 2 kelps les plus loin des poissons au démarrage. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (EditCondition = "bIsTutorial"))
	FName TutorialFarKelpTag = TEXT("TutoKelpFar");

	/** Widget du panneau de guidage. Vide = UTutorialWidget (panneau construit en C++, sans asset). Un WBP enfant
	 *  peut le remplacer en reprenant les noms TitleText, MessageText, StepText, ProgressText, WarningText. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (EditCondition = "bIsTutorial"))
	TSubclassOf<UTutorialWidget> TutorialWidgetClass;

	/** Décalage vertical [px] du panneau de guidage depuis le haut de l'écran. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tutorial", meta = (EditCondition = "bIsTutorial"))
	float TutorialPanelTopOffset = 120.f;

	// ---------------------------------------------------------------- Debug
	/** Affiche l'état de l'écosystème en texte à l'écran (retiré des builds Shipping). */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Debug")
	bool bShowDebugHUD = true;
};

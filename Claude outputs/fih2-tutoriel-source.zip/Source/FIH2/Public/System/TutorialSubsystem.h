// Tutoriel guidé du niveau 1.
//
// Actif si la ULevelConfig du niveau a bIsTutorial. Enchaîne les étapes de ULevelConfig::TutorialSteps et affiche
// le panneau de guidage (UTutorialWidget). Aucun Tick : tout avance au rythme de la simulation
// (UEcosystemSubsystem::OnUpdated, toutes les SIM_TICK s) et de la sélection (AMouseController::OnSelectionChanged).
//
// Règles du tutoriel (décisions du 13/11/2026) :
//  - défaite (jauge, extinction) et mort de faim désactivées jusqu'à l'étape FinalHold ;
//  - le chrono tourne dès le début mais l'objectif chronométré (DUREE_NIVEAU) est ignoré ;
//  - victoire = jauge hors du rouge pendant la durée de l'étape FinalHold ; un passage au rouge remet le compte à zéro.

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "System/EcosystemSubsystem.h"
#include "System/LevelConfig.h"
#include "TutorialSubsystem.generated.h"

class AKelp;
class AMouseController;
class UTutorialWidget;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnTutorialStepChanged, int32, StepIndex, ETutorialStepType, StepType);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnTutorialCompleted);

UCLASS()
class FIH2_API UTutorialSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	static UTutorialSubsystem* Get(const UObject* WorldContext);

	virtual bool DoesSupportWorldType(const EWorldType::Type WorldType) const override;
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;

	UFUNCTION(BlueprintPure, Category = "Tutorial")
	bool IsTutorialActive() const { return bActive; }

	/** Index de l'étape courante (0 = première), -1 avant le début ou hors tutoriel. */
	UFUNCTION(BlueprintPure, Category = "Tutorial")
	int32 GetCurrentStepIndex() const { return StepIndex; }

	/** Passe à l'étape suivante sans attendre sa condition (debug, ou bouton « passer » plus tard). */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void SkipStep();

	UPROPERTY(BlueprintAssignable, Category = "Tutorial")
	FOnTutorialStepChanged OnStepChanged;

	UPROPERTY(BlueprintAssignable, Category = "Tutorial")
	FOnTutorialCompleted OnCompleted;

private:
	UFUNCTION()
	void HandleEcosystemUpdated(const FEcosystemSnapshot& Snapshot);

	UFUNCTION()
	void HandleEcosystemStateChanged(EEcosystemState NewState);

	UFUNCTION()
	void HandleSelectionChanged(AActor* NewSelection);

	/** Premier pas de simulation : le joueur, son contrôleur et les acteurs du niveau existent. */
	void Start();
	void EnterStep(int32 NewIndex);
	/** Évalue la condition de l'étape courante. Dt = temps de simulation écoulé depuis le dernier appel. */
	bool IsStepDone(const FTutorialStep& Step, const FEcosystemSnapshot& Snapshot, float Dt);
	void UpdateFinalHold(const FTutorialStep& Step, const FEcosystemSnapshot& Snapshot, float Dt);
	void ResolveFarKelps();
	FVector GetNearKelpsCenter() const;
	void Stop();

	UPROPERTY(Transient)
	TObjectPtr<UEcosystemSubsystem> Ecosystem;

	UPROPERTY(Transient)
	TObjectPtr<ULevelConfig> Config;

	UPROPERTY(Transient)
	TObjectPtr<UTutorialWidget> Widget;

	TWeakObjectPtr<AMouseController> Controller;
	TArray<TWeakObjectPtr<AKelp>> FarKelps;

	bool bActive = false;
	bool bStarted = false;
	int32 StepIndex = -1;

	// État de l'étape courante (remis à zéro par EnterStep)
	float StepTime = 0.f;
	float StepCounter = 0.f;       // durée de saisie, d'observation ou de maintien selon l'étape
	float LastElapsed = 0.f;
	float WarningTimeLeft = 0.f;
	bool bFishSelected = false;
	FVector CameraStartLocation = FVector::ZeroVector;
	FRotator CameraStartRotation = FRotator::ZeroRotator;
};

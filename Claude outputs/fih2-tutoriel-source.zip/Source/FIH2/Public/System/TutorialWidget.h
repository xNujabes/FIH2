// Panneau de guidage du tutoriel (haut de l'écran).
//
// Fonctionne sans asset : si aucun arbre de widgets n'existe (classe C++ utilisée directement), il construit
// lui-même un panneau simple (titre, message, ligne de progression, avertissement). Un Widget Blueprint enfant
// peut fournir son propre design en nommant ses TextBlock comme les BindWidgetOptional ci-dessous.
// Le panneau ne capte pas la souris (HitTestInvisible) : clic, sélection et drag & throw passent au travers.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "TutorialWidget.generated.h"

class UTextBlock;

UCLASS()
class FIH2_API UTutorialWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	/** Affiche une étape. StepNumber commence à 1. */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void ShowStep(int32 StepNumber, int32 StepCount, const FText& Title, const FText& Message);

	/** Ligne de progression sous le message (texte vide = masquée). */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void SetProgress(const FText& Progress);

	/** Avertissement en couleur (texte vide = masqué). */
	UFUNCTION(BlueprintCallable, Category = "Tutorial")
	void SetWarning(const FText& Warning);

protected:
	virtual void NativeOnInitialized() override;
	virtual TSharedRef<SWidget> RebuildWidget() override;

	/** Pour animer un WBP enfant à chaque nouvelle étape. */
	UFUNCTION(BlueprintImplementableEvent, Category = "Tutorial")
	void OnStepShown(int32 StepNumber, int32 StepCount);

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial", meta = (BindWidgetOptional))
	TObjectPtr<UTextBlock> StepText;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial", meta = (BindWidgetOptional))
	TObjectPtr<UTextBlock> TitleText;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial", meta = (BindWidgetOptional))
	TObjectPtr<UTextBlock> MessageText;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial", meta = (BindWidgetOptional))
	TObjectPtr<UTextBlock> ProgressText;

	UPROPERTY(BlueprintReadOnly, Category = "Tutorial", meta = (BindWidgetOptional))
	TObjectPtr<UTextBlock> WarningText;

	/** Panneau par défaut : largeur maximale [px]. */
	UPROPERTY(EditDefaultsOnly, Category = "Tutorial|Default Layout")
	float PanelMaxWidth = 640.f;

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial|Default Layout")
	FLinearColor BackgroundColor = FLinearColor(0.f, 0.03f, 0.07f, 0.78f);

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial|Default Layout")
	FLinearColor AccentColor = FLinearColor(0.35f, 0.85f, 1.f, 1.f);

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial|Default Layout")
	FLinearColor WarningColor = FLinearColor(1.f, 0.35f, 0.25f, 1.f);

private:
	void BuildDefaultTree();
	static void SetLine(UTextBlock* Block, const FText& Text);
};
